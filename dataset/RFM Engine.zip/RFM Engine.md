```python
import pandas as pd
import numpy as np

```


```python
df = pd.read_csv(r'C:\Ongoing course\Projects\Dunnhumby RFM segmentation\transaction_data.csv')
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>household_key</th>
      <th>BASKET_ID</th>
      <th>DAY</th>
      <th>PRODUCT_ID</th>
      <th>QUANTITY</th>
      <th>SALES_VALUE</th>
      <th>STORE_ID</th>
      <th>RETAIL_DISC</th>
      <th>TRANS_TIME</th>
      <th>WEEK_NO</th>
      <th>COUPON_DISC</th>
      <th>COUPON_MATCH_DISC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2375</td>
      <td>26984851472</td>
      <td>1</td>
      <td>1004906</td>
      <td>1</td>
      <td>1.39</td>
      <td>364</td>
      <td>-0.60</td>
      <td>1631</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2375</td>
      <td>26984851472</td>
      <td>1</td>
      <td>1033142</td>
      <td>1</td>
      <td>0.82</td>
      <td>364</td>
      <td>0.00</td>
      <td>1631</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2375</td>
      <td>26984851472</td>
      <td>1</td>
      <td>1036325</td>
      <td>1</td>
      <td>0.99</td>
      <td>364</td>
      <td>-0.30</td>
      <td>1631</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2375</td>
      <td>26984851472</td>
      <td>1</td>
      <td>1082185</td>
      <td>1</td>
      <td>1.21</td>
      <td>364</td>
      <td>0.00</td>
      <td>1631</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2375</td>
      <td>26984851472</td>
      <td>1</td>
      <td>8160430</td>
      <td>1</td>
      <td>1.50</td>
      <td>364</td>
      <td>-0.39</td>
      <td>1631</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#how many rows and columns?
df.shape
```




    (2595732, 12)




```python
#is household_key int or object?
df.dtypes
```




    household_key          int64
    BASKET_ID              int64
    DAY                    int64
    PRODUCT_ID             int64
    QUANTITY               int64
    SALES_VALUE          float64
    STORE_ID               int64
    RETAIL_DISC          float64
    TRANS_TIME             int64
    WEEK_NO                int64
    COUPON_DISC          float64
    COUPON_MATCH_DISC    float64
    dtype: object




```python
 #is the min negative?
df['SALES_VALUE'].describe()
```




    count    2.595732e+06
    mean     3.104120e+00
    std      4.182274e+00
    min      0.000000e+00
    25%      1.290000e+00
    50%      2.000000e+00
    75%      3.490000e+00
    max      8.400000e+02
    Name: SALES_VALUE, dtype: float64




```python
#what's the range?
df['DAY'].agg(['min','max'])
```




    min      1
    max    711
    Name: DAY, dtype: int64




```python
# no. of unique households?
df['household_key'].nunique()
```




    2500




```python
# How many zero-value rows exist?
print(df[df['SALES_VALUE'] == 0].shape[0])

# What do those rows look like?
print(df[df['SALES_VALUE'] == 0][['QUANTITY','SALES_VALUE','RETAIL_DISC','COUPON_DISC']].describe())

# Check the discount columns for negatives
print(df[['RETAIL_DISC','COUPON_DISC','COUPON_MATCH_DISC']].describe())
```

    18850
               QUANTITY  SALES_VALUE   RETAIL_DISC   COUPON_DISC
    count  18850.000000      18850.0  18850.000000  18850.000000
    mean       0.241061          0.0     -0.781153     -0.550489
    std        0.443091          0.0      1.816268      1.505729
    min        0.000000          0.0    -39.950000    -37.930000
    25%        0.000000          0.0      0.000000     -0.500000
    50%        0.000000          0.0      0.000000      0.000000
    75%        0.000000          0.0      0.000000      0.000000
    max        9.000000          0.0      0.010000      0.000000
            RETAIL_DISC   COUPON_DISC  COUPON_MATCH_DISC
    count  2.595732e+06  2.595732e+06       2.595732e+06
    mean  -5.387054e-01 -1.641600e-02      -2.918564e-03
    std    1.249191e+00  2.168410e-01       3.969004e-02
    min   -1.800000e+02 -5.593000e+01      -7.700000e+00
    25%   -6.900000e-01  0.000000e+00       0.000000e+00
    50%   -1.000000e-02  0.000000e+00       0.000000e+00
    75%    0.000000e+00  0.000000e+00       0.000000e+00
    max    3.990000e+00  0.000000e+00       0.000000e+00
    


```python
# Are zero-value rows entire baskets, or just items within larger baskets?
zero_baskets = df[df['SALES_VALUE'] == 0]['BASKET_ID'].unique()
basket_totals = df.groupby('BASKET_ID')['SALES_VALUE'].sum()

# How many of those baskets have ZERO total value across all items?
fully_zero = basket_totals[basket_totals == 0]
print(f"Baskets with at least one zero-value item: {len(zero_baskets)}")
print(f"Baskets where ALL items are zero-value:    {len(fully_zero)}")
print(f"As % of all baskets: {len(fully_zero)/basket_totals.shape[0]*100:.2f}%")
```

    Baskets with at least one zero-value item: 16305
    Baskets where ALL items are zero-value:    942
    As % of all baskets: 0.34%
    


```python
# ── Step 1: compute the three raw metrics ──────────────────────────────

recency = 712 - df.groupby('household_key')['DAY'].max()
frequency = df.groupby('household_key')['BASKET_ID'].nunique()
monetary = (df[df['SALES_VALUE'] > 0]
              .groupby('household_key')['SALES_VALUE']
              .sum())

# ── Step 2: combine into one dataframe ─────────────────────────────────

rfm = pd.concat([recency, frequency, monetary], axis=1)
rfm.columns = ['recency_days', 'frequency', 'monetary']
rfm = rfm.reset_index()

# ── Step 3: verify ─────────────────────────────────────────────────────

print(rfm.shape)         
print(rfm.isnull().sum()) 
print(rfm.describe())     
print(rfm.head())         
```

    (2500, 4)
    household_key    0
    recency_days     0
    frequency        0
    monetary         0
    dtype: int64
           household_key  recency_days    frequency      monetary
    count     2500.00000   2500.000000  2500.000000   2500.000000
    mean      1250.50000     26.574000   110.593600   3222.985232
    std        721.83216     62.790655   115.669368   3349.026076
    min          1.00000      1.000000     1.000000      8.170000
    25%        625.75000      2.000000    39.000000    970.740000
    50%       1250.50000      7.000000    79.000000   2157.750000
    75%       1875.25000     21.000000   142.250000   4413.320000
    max       2500.00000    658.000000  1300.000000  38319.790000
       household_key  recency_days  frequency  monetary
    0              1             6         86   4330.16
    1              2            44         45   1954.34
    2              3             9         47   2653.21
    3              4            85         30   1200.11
    4              5             9         40    779.06
    


```python
rfm['R'] = pd.qcut(rfm['recency_days'].rank(method='first'), q=5, labels=[5,4,3,2,1])
rfm['F'] = pd.qcut(rfm['frequency'].rank(method='first'), q=5, labels=[1,2,3,4,5])
rfm['M'] = pd.qcut(rfm['monetary'], q=5, labels=[1,2,3,4,5])

rfm['RFM_Score'] = rfm['R'].astype(int) + rfm['F'].astype(int) + rfm['M'].astype(int)
```


```python
rfm['R'].value_counts().sort_index()

```




    R
    5    500
    4    500
    3    500
    2    500
    1    500
    Name: count, dtype: int64




```python
rfm['RFM_Score'].describe()

```




    count    2500.000000
    mean        9.000000
    std         3.627956
    min         3.000000
    25%         6.000000
    50%         9.000000
    75%        12.000000
    max        15.000000
    Name: RFM_Score, dtype: float64




```python
rfm['RFM_Score'].mean()
```




    9.0




```python
rfm[['R','F','M']].apply(pd.Series.value_counts).fillna(0).astype(int)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>R</th>
      <th>F</th>
      <th>M</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>500</td>
      <td>500</td>
      <td>500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>500</td>
      <td>500</td>
      <td>500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>500</td>
      <td>500</td>
      <td>500</td>
    </tr>
    <tr>
      <th>4</th>
      <td>500</td>
      <td>500</td>
      <td>500</td>
    </tr>
    <tr>
      <th>5</th>
      <td>500</td>
      <td>500</td>
      <td>500</td>
    </tr>
  </tbody>
</table>
</div>




```python
rfm['R']= rfm['R'].astype(int)
rfm['F']= rfm['F'].astype(int)
rfm['M']= rfm['M'].astype(int)
```


```python
import numpy as np

r = rfm['R']
f = rfm['F']
m = rfm['M']

conditions = [
    (r >= 4) & (f >= 4) & (m >= 4),   # Champions
    (f >= 4) & (r >= 3),               # Loyal
    (r>=4) & ((f==2)|(f==3)),# Potential loyalists
    ((r==2)|(r==3)) & (f>=2) & (m>=2),# At risk
    (r == 5) & (f == 1),               # New customers
    (r==1),# Lost
    ((r==2)|(r==3)|(r==4)) & (f==1), # One-time Buyers
    ((r==2)|(r==3)) & (f>=2) & (m==1) # Low Value
]

choices = [
    'Champions',
    'Loyal',
    'Potential Loyalists',
    'At Risk',
    'New Customers',
    'Lost',
    'One-time Buyers',
    'Low Value'
]

rfm['segment'] = np.select(conditions, choices, default='Others')
```


```python
print(rfm['segment'].value_counts())
print(f"Uncategorised: {(rfm['segment'] == 'Others').sum()}")
```

    segment
    At Risk                565
    Champions              509
    Lost                   500
    Loyal                  330
    Potential Loyalists    306
    One-time Buyers        198
    Low Value               62
    New Customers           30
    Name: count, dtype: int64
    Uncategorised: 0
    


```python
others = rfm[rfm['segment'] == 'Others']
print(others.groupby(['R','F','M']).size().reset_index(name='count').sort_values('count', ascending=False).head(20))
```

    Empty DataFrame
    Columns: [R, F, M, count]
    Index: []
    


```python
import matplotlib.pyplot as plt

# shared variable — compute once, use everywhere
segment_counts = rfm['segment'].value_counts()
score_counts   = rfm['RFM_Score'].value_counts().sort_index()
segment_avg    = rfm.groupby('segment')[['R','F','M']].mean().round(2)

# Chart 1
plt.figure(figsize=(10,5))
plt.bar(segment_counts.index, segment_counts.values, color='teal')
plt.title('Customer Segments')
plt.ylabel('Number of Households')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

# Chart 2
plt.figure(figsize=(8,4))
plt.bar(score_counts.index, score_counts.values, color='steelblue')
plt.title('RFM Score Distribution')
plt.xlabel('RFM Score')
plt.ylabel('Number of Households')
plt.xticks(score_counts.index)
plt.tight_layout()
plt.show()

# Chart 3
segment_avg.plot(kind='bar', figsize=(10,5))
plt.title('Average R / F / M Score per Segment')
plt.ylabel('Score (1–5)')
plt.xticks(rotation=45, ha='right')
plt.legend(['Recency','Frequency','Monetary'])
plt.tight_layout()
plt.show()

# Chart 4
plt.figure(figsize=(5,5))
plt.pie(segment_counts.values,
        labels=segment_counts.index,
        autopct='%1.1f%%',
        startangle=140)
plt.title('Household Share by Segment')
plt.tight_layout()
plt.show()
```


    
![png](output_19_0.png)
    



    
![png](output_19_1.png)
    



    
![png](output_19_2.png)
    



    
![png](output_19_3.png)
    



```python
demo = pd.read_csv(r'C:\Ongoing course\Projects\Dunnhumby RFM segmentation\hh_demographic.csv')

print(demo.shape)
print(demo.dtypes)
print(demo.isnull().sum())
print(demo['household_key'].nunique())
print(demo.head())
```

    (801, 8)
    AGE_DESC               object
    MARITAL_STATUS_CODE    object
    INCOME_DESC            object
    HOMEOWNER_DESC         object
    HH_COMP_DESC           object
    HOUSEHOLD_SIZE_DESC    object
    KID_CATEGORY_DESC      object
    household_key           int64
    dtype: object
    AGE_DESC               0
    MARITAL_STATUS_CODE    0
    INCOME_DESC            0
    HOMEOWNER_DESC         0
    HH_COMP_DESC           0
    HOUSEHOLD_SIZE_DESC    0
    KID_CATEGORY_DESC      0
    household_key          0
    dtype: int64
    801
      AGE_DESC MARITAL_STATUS_CODE INCOME_DESC HOMEOWNER_DESC      HH_COMP_DESC  \
    0      65+                   A      35-49K      Homeowner  2 Adults No Kids   
    1    45-54                   A      50-74K      Homeowner  2 Adults No Kids   
    2    25-34                   U      25-34K        Unknown     2 Adults Kids   
    3    25-34                   U      75-99K      Homeowner     2 Adults Kids   
    4    45-54                   B      50-74K      Homeowner     Single Female   
    
      HOUSEHOLD_SIZE_DESC KID_CATEGORY_DESC  household_key  
    0                   2      None/Unknown              1  
    1                   2      None/Unknown              7  
    2                   3                 1              8  
    3                   4                 2             13  
    4                   1      None/Unknown             16  
    


```python
rfm_demo = pd.merge(rfm, demo, on='household_key', how='left')

print(rfm_demo.shape)
print(rfm_demo['INCOME_DESC'].isnull().sum())
```

    (2500, 16)
    1699
    


```python
print(rfm_demo['INCOME_DESC'].value_counts())
print(rfm_demo['HOUSEHOLD_SIZE_DESC'].value_counts())
```

    INCOME_DESC
    50-74K       192
    35-49K       172
    75-99K        96
    25-34K        77
    15-24K        74
    Under 15K     61
    125-149K      38
    100-124K      34
    150-174K      30
    250K+         11
    175-199K      11
    200-249K       5
    Name: count, dtype: int64
    HOUSEHOLD_SIZE_DESC
    2     318
    1     255
    3     109
    5+     66
    4      53
    Name: count, dtype: int64
    


```python
income_order = [
    'Under 15K', '15-24K', '25-34K', '35-49K', '50-74K',
    '75-99K', '100-124K', '125-149K', '150-174K', '175-199K',
    '200-249K', '250K+'
]

size_order = ['1', '2', '3', '4', '5+']
```


```python
import pandas as pd

# filter to only the 801 households with demographics
rfm_known = rfm_demo[rfm_demo['INCOME_DESC'].notnull()]

# crosstab: rows = income bands, columns = segments
income_ct = pd.crosstab(
    rfm_known['INCOME_DESC'],
    rfm_known['segment'],
    normalize='index'   # converts counts to row %
)

# reindex rows to correct income order
income_ct = income_ct.reindex(income_order)

print(income_ct.round(2))
```

    segment      At Risk  Champions  Lost  Low Value  Loyal  One-time Buyers  \
    INCOME_DESC                                                                
    Under 15K       0.21       0.49  0.05       0.00   0.20             0.00   
    15-24K          0.20       0.35  0.09       0.00   0.27             0.00   
    25-34K          0.16       0.39  0.08       0.00   0.25             0.00   
    35-49K          0.16       0.44  0.06       0.01   0.20             0.01   
    50-74K          0.19       0.43  0.03       0.01   0.24             0.01   
    75-99K          0.20       0.39  0.06       0.00   0.19             0.00   
    100-124K        0.24       0.44  0.03       0.00   0.24             0.00   
    125-149K        0.21       0.45  0.08       0.00   0.18             0.03   
    150-174K        0.30       0.37  0.07       0.00   0.23             0.00   
    175-199K        0.09       0.64  0.00       0.00   0.09             0.00   
    200-249K        0.20       0.40  0.00       0.00   0.20             0.00   
    250K+           0.00       0.91  0.00       0.00   0.00             0.00   
    
    segment      Potential Loyalists  
    INCOME_DESC                       
    Under 15K                   0.05  
    15-24K                      0.08  
    25-34K                      0.13  
    35-49K                      0.12  
    50-74K                      0.09  
    75-99K                      0.17  
    100-124K                    0.06  
    125-149K                    0.05  
    150-174K                    0.03  
    175-199K                    0.18  
    200-249K                    0.20  
    250K+                       0.09  
    


```python
# Chart 1 — segment mix by income band
income_ct.plot(kind='bar', stacked=True, figsize=(12, 5))
plt.title('Segment Mix by Income Band')
plt.ylabel('Proportion of Households')
plt.xlabel('Income Band')
plt.xticks(rotation=45, ha='right')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)
plt.tight_layout()
plt.show()

# Chart 2 — segment mix by household size
size_ct = pd.crosstab(
    rfm_known['HOUSEHOLD_SIZE_DESC'],
    rfm_known['segment'],
    normalize='index'
).reindex(size_order)

size_ct.plot(kind='bar', stacked=True, figsize=(8, 5))
plt.title('Segment Mix by Household Size')
plt.ylabel('Proportion of Households')
plt.xlabel('Household Size')
plt.xticks(rotation=0)
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)
plt.tight_layout()
plt.show()
```


    
![png](output_25_0.png)
    



    
![png](output_25_1.png)
    



```python
campaign_table = pd.read_csv(r'C:\Ongoing course\Projects\Dunnhumby RFM segmentation\campaign_table.csv')
campaign_desc  = pd.read_csv(r'C:\Ongoing course\Projects\Dunnhumby RFM segmentation\campaign_desc.csv')
coupon_redempt = pd.read_csv(r'C:\Ongoing course\Projects\Dunnhumby RFM segmentation\coupon_redempt.csv')

print(campaign_table.shape, campaign_table.columns.tolist())
print(campaign_desc.shape,  campaign_desc.columns.tolist())
print(coupon_redempt.shape, coupon_redempt.columns.tolist())
```

    (7208, 3) ['DESCRIPTION', 'household_key', 'CAMPAIGN']
    (30, 4) ['DESCRIPTION', 'CAMPAIGN', 'START_DAY', 'END_DAY']
    (2318, 4) ['household_key', 'DAY', 'COUPON_UPC', 'CAMPAIGN']
    


```python
campaign_desc['DESCRIPTION'].nunique()
```




    3




```python
print(campaign_table['household_key'].nunique())
print(campaign_table['CAMPAIGN'].nunique())
print(campaign_table.groupby('household_key')['CAMPAIGN'].count().describe())
```

    1584
    30
    count    1584.000000
    mean        4.550505
    std         2.993988
    min         1.000000
    25%         2.000000
    50%         4.000000
    75%         6.000000
    max        17.000000
    Name: CAMPAIGN, dtype: float64
    


```python
print(campaign_desc['DESCRIPTION'].value_counts())
print(campaign_desc[['START_DAY','END_DAY']].describe())
```

    DESCRIPTION
    TypeB    19
    TypeC     6
    TypeA     5
    Name: count, dtype: int64
            START_DAY     END_DAY
    count   30.000000   30.000000
    mean   463.866667  510.466667
    std    134.488490  137.730555
    min    224.000000  264.000000
    25%    360.000000  405.750000
    50%    470.000000  502.000000
    75%    584.000000  640.250000
    max    659.000000  719.000000
    


```python
# Step 1: give every household their campaign window
camp = pd.merge(campaign_table, campaign_desc[['CAMPAIGN', 'START_DAY', 'END_DAY']], on='CAMPAIGN', how='left')

# Step 2: bring in transactions
camp_txn = pd.merge(camp, df[['household_key','BASKET_ID','DAY']],
                    on='household_key', how='left')

print(camp.shape)      
print(camp_txn.shape)  
```

    (7208, 5)
    (14025241, 7)
    


```python
print(camp.columns.tolist())
```

    ['DESCRIPTION', 'household_key', 'CAMPAIGN', 'START_DAY', 'END_DAY']
    


```python
camp.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DESCRIPTION</th>
      <th>household_key</th>
      <th>CAMPAIGN</th>
      <th>START_DAY</th>
      <th>END_DAY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>TypeA</td>
      <td>17</td>
      <td>26</td>
      <td>224</td>
      <td>264</td>
    </tr>
    <tr>
      <th>1</th>
      <td>TypeA</td>
      <td>27</td>
      <td>26</td>
      <td>224</td>
      <td>264</td>
    </tr>
    <tr>
      <th>2</th>
      <td>TypeA</td>
      <td>212</td>
      <td>26</td>
      <td>224</td>
      <td>264</td>
    </tr>
    <tr>
      <th>3</th>
      <td>TypeA</td>
      <td>208</td>
      <td>26</td>
      <td>224</td>
      <td>264</td>
    </tr>
    <tr>
      <th>4</th>
      <td>TypeA</td>
      <td>192</td>
      <td>26</td>
      <td>224</td>
      <td>264</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(camp_txn.columns.tolist())
```

    ['DESCRIPTION', 'household_key', 'CAMPAIGN', 'START_DAY', 'END_DAY', 'BASKET_ID', 'DAY']
    


```python
# filter to transactions within campaign window
responded = camp_txn[
    (camp_txn['DAY'] >= camp_txn['START_DAY']) &
    (camp_txn['DAY'] <= camp_txn['END_DAY'])
]

print(responded.shape)
print(responded['household_key'].nunique())
```

    (994137, 7)
    1552
    


```python
# Step 4 — get one row per household-campaign pair, flag as responded
responders = responded.groupby(
                ['household_key','CAMPAIGN']
             )['BASKET_ID'].count().reset_index()
responders.columns = ['household_key','CAMPAIGN','txn_count']
responders['responded'] = 1

# merge back to full targeted list so non-responders get responded=0
camp_response = pd.merge(
    camp[['household_key','CAMPAIGN','DESCRIPTION']].drop_duplicates(),
    responders[['household_key','CAMPAIGN','responded']],
    on=['household_key','CAMPAIGN'],
    how='left'
)
camp_response['responded'] = camp_response['responded'].fillna(0).astype(int)

print(camp_response['responded'].value_counts())
print(camp_response.shape)
```

    responded
    1    7056
    0     152
    Name: count, dtype: int64
    (7208, 4)
    


```python
print(camp_response.columns.tolist())
```

    ['household_key', 'CAMPAIGN', 'DESCRIPTION', 'responded']
    


```python
print(rfm_demo.columns.tolist())
```

    ['household_key', 'recency_days', 'frequency', 'monetary', 'R', 'F', 'M', 'RFM_Score', 'segment', 'AGE_DESC', 'MARITAL_STATUS_CODE', 'INCOME_DESC', 'HOMEOWNER_DESC', 'HH_COMP_DESC', 'HOUSEHOLD_SIZE_DESC', 'KID_CATEGORY_DESC']
    


```python
# Step 5 — join segments and calculate response rate per segment
# hint: merge camp_response with rfm_demo on household_key
# then groupby segment and calculate mean of responded column

camp_seg = pd.merge(camp_response,rfm_demo[['household_key','segment']], on='household_key', how='left')
response_rate = camp_seg.groupby('segment')['responded'].mean().round(3).sort_values(ascending=False)
print(response_rate)
```

    segment
    New Customers          1.000
    Loyal                  0.999
    Champions              0.996
    Potential Loyalists    0.972
    At Risk                0.968
    Low Value              0.923
    Lost                   0.863
    One-time Buyers        0.812
    Name: responded, dtype: float64
    


```python
# targeted count per segment — needed for context
targeted_count = camp_seg.groupby('segment')['household_key'].nunique()
print(targeted_count)
```

    segment
    At Risk                393
    Champions              499
    Lost                   167
    Low Value                9
    Loyal                  310
    New Customers            2
    One-time Buyers         20
    Potential Loyalists    184
    Name: household_key, dtype: int64
    


```python
overall_avg = camp_response['responded'].mean().round(3)
print(f"Overall avg: {overall_avg:.1%}")
```

    Overall avg: 97.9%
    


```python
import matplotlib.pyplot as plt
import numpy as np

# ── data from your outputs ──────────────────────────────────────────────
segments = response_rate.index.tolist()
rates    = response_rate.values.tolist()
targeted = [targeted_count[s] for s in segments]

# ── Chart 1: Response rate by segment ──────────────────────────────────
plt.figure(figsize=(10, 5))
bars = plt.bar(segments, rates, color='steelblue')
plt.axhline(y=overall_avg, color='red', linestyle='--', linewidth=1, label=f'Overall avg ({overall_avg:.1%})')
plt.title('Campaign Response Rate by Segment')
plt.ylabel('Response Rate')
plt.ylim(0.7, 1.05)
plt.xticks(rotation=45, ha='right')
plt.legend()

# value labels on bars
for bar, val in zip(bars, rates):
    plt.text(bar.get_x() + bar.get_width()/2,
             bar.get_height() + 0.003,
             f'{val:.1%}', ha='center', va='bottom', fontsize=8)
plt.tight_layout()
plt.show()


# ── Chart 2: Households targeted per segment ───────────────────────────
plt.figure(figsize=(10, 5))
bars2 = plt.bar(segments, targeted, color='coral')
plt.title('Households Targeted per Segment')
plt.ylabel('Number of Households')
plt.xticks(rotation=45, ha='right')

for bar, val in zip(bars2, targeted):
    plt.text(bar.get_x() + bar.get_width()/2,
             bar.get_height() + 3,
             str(val), ha='center', va='bottom', fontsize=8)
plt.tight_layout()
plt.show()


# ── Chart 3: Response rate vs targeted — bubble chart ──────────────────
# size of bubble = number targeted, position = response rate
plt.figure(figsize=(10, 6))
x = range(len(segments))
plt.scatter(x, rates,
            s=[t * 0.8 for t in targeted],   # bubble size proportional to targeted
            color='steelblue', alpha=0.6, edgecolors='white', linewidth=0.8)

plt.axhline(y=overall_avg, color='red', linestyle='--', linewidth=1, label=f'Overall avg ({overall_avg:.1%})')
plt.xticks(x, segments, rotation=45, ha='right')
plt.ylabel('Response Rate')
plt.title('Response Rate vs Targeting Volume\n(bubble size = households targeted)')

# label each bubble
for i, (seg, rate, tgt) in enumerate(zip(segments, rates, targeted)):
    plt.annotate(f'{tgt} hh', (i, rate),
                 textcoords='offset points', xytext=(0, 12),
                 ha='center', fontsize=8, color='gray')
plt.legend()
plt.tight_layout()
plt.show()
```


    
![png](output_41_0.png)
    



    
![png](output_41_1.png)
    



    
![png](output_41_2.png)
    



```python
coupon_counts = coupon_redempt.groupby('household_key')['COUPON_UPC'].count().reset_index()
coupon_counts.columns = ['household_key', 'redemption_count']

coupon_seg = pd.merge(rfm_demo[['household_key','segment']],
                      coupon_counts,
                      on='household_key',
                      how='left')

coupon_seg['redemption_count'] = coupon_seg['redemption_count'].fillna(0).astype(int)
coupon_seg['redeemed'] = (coupon_seg['redemption_count'] > 0).astype(int)

redemption_rate = coupon_seg.groupby('segment')['redeemed'].mean().round(3).sort_values(ascending=False)
avg_redemptions = coupon_seg.groupby('segment')['redemption_count'].mean().round(2).sort_values(ascending=False)

print(redemption_rate)
print(avg_redemptions)
```

    segment
    Champions              0.428
    Loyal                  0.279
    Potential Loyalists    0.111
    At Risk                0.110
    Lost                   0.054
    One-time Buyers        0.005
    Low Value              0.000
    New Customers          0.000
    Name: redeemed, dtype: float64
    segment
    Champions              2.74
    Loyal                  1.33
    At Risk                0.43
    Potential Loyalists    0.42
    Lost                   0.23
    One-time Buyers        0.01
    Low Value              0.00
    New Customers          0.00
    Name: redemption_count, dtype: float64
    


```python
# what % of total coupon redemptions do Champions account for?
total_redemptions = coupon_seg['redemption_count'].sum()
champ_redemptions = coupon_seg[coupon_seg['segment'] == 'Champions']['redemption_count'].sum()

total_households = rfm.shape[0]
champ_households = rfm[rfm['segment']=='Champions'].shape[0]

print(f"Champions share of all redemptions: {champ_redemptions/total_redemptions:.1%}")
print(f"Champions share of households: {champ_households/total_households:.1%}")
```

    Champions share of all redemptions: 60.1%
    Champions share of households: 20.4%
    


```python
# Chart 1 — redemption rate by segment
plt.figure(figsize=(10, 5))
bars = plt.bar(redemption_rate.index, redemption_rate.values, color='steelblue')
overall_redemption = coupon_seg['redeemed'].mean()
plt.axhline(y=overall_redemption, color='red', linestyle='--',
            linewidth=1, label=f'Overall avg ({overall_redemption:.1%})')
plt.title('Coupon Redemption Rate by Segment')
plt.ylabel('Redemption Rate')
plt.xticks(rotation=45, ha='right')
for bar, val in zip(bars, redemption_rate.values):
    plt.text(bar.get_x() + bar.get_width()/2,
             bar.get_height() + 0.003,
             f'{val:.1%}', ha='center', va='bottom', fontsize=8)
plt.legend()
plt.tight_layout()
plt.show()

# Chart 2 — average redemptions per household by segment
plt.figure(figsize=(10, 5))
bars2 = plt.bar(avg_redemptions.index, avg_redemptions.values, color='coral')
plt.title('Avg Coupon Redemptions per Household by Segment')
plt.ylabel('Avg Redemptions')
plt.xticks(rotation=45, ha='right')
for bar, val in zip(bars2, avg_redemptions.values):
    plt.text(bar.get_x() + bar.get_width()/2,
             bar.get_height() + 0.02,
             f'{val}', ha='center', va='bottom', fontsize=8)
plt.tight_layout()
plt.show()

# Chart 3 — redemption concentration (Champions vs everyone else)
total_redemptions = coupon_seg['redemption_count'].sum()
champ_redemptions = coupon_seg[coupon_seg['segment'] == 'Champions']['redemption_count'].sum()
other_redemptions = total_redemptions - champ_redemptions

plt.figure(figsize=(6, 6))
plt.pie([champ_redemptions, other_redemptions],
        labels=['Champions', 'All Other Segments'],
        autopct='%1.1f%%',
        colors=['steelblue', 'lightgray'],
        startangle=90)
plt.title('Share of Total Coupon Redemptions\nChampions vs Everyone Else')
plt.tight_layout()
plt.show()
```


    
![png](output_44_0.png)
    



    
![png](output_44_1.png)
    



    
![png](output_44_2.png)
    



```python
rfm_segments = rfm_demo[[
    'household_key', 'recency_days', 'frequency', 'monetary',
    'R', 'F', 'M', 'RFM_Score', 'segment',
    'INCOME_DESC', 'HOUSEHOLD_SIZE_DESC', 'AGE_DESC',
    'MARITAL_STATUS_CODE', 'HH_COMP_DESC', 'KID_CATEGORY_DESC'
]]

rfm_segments.to_csv(r'C:\Ongoing course\Projects\Dunnhumby RFM segmentation\created\rfm_segments.csv', index=False)
print(rfm_segments.shape)
print(rfm_segments['segment'].value_counts())
```

    (2500, 15)
    segment
    At Risk                565
    Champions              509
    Lost                   500
    Loyal                  330
    Potential Loyalists    306
    One-time Buyers        198
    Low Value               62
    New Customers           30
    Name: count, dtype: int64
    


```python

```
